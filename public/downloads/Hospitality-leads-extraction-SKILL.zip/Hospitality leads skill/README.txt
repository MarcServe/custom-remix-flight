Hospitality verified leads — extraction skill

1. Unzip this folder onto your Desktop.
2. Open Hospitality-leads-extraction-method.txt
3. In Cursor, the same skill lives at .cursor/skills/hospitality-verified-leads/SKILL.md
